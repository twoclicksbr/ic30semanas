<section class="wrapper image-wrapper bg-image bg-overlay bg-overlay-light-100 text-white"
    data-image-src="/assets/img/banner.jpg"
    style="background-image: url('/assets/img/banner.jpg');">
    <div class="container pt-17 pb-20 pt-md-19 pb-md-21 text-center">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                {{-- <h1 class="display-1 mb-3 text-white"> Alex </h1> --}}

            </div>
        </div>
    </div>
</section>
